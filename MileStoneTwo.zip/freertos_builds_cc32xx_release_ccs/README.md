## Project Summary

This project contains the configuration for building a FreeRTOS kernel.

## Project Usage

This project is the default configuration used by all of the SimpleLink
FreeRTOS examples.

Please refer to the FreeRTOS Kernel section in the SimpleLink MCU SDK User's
Guide for the details on how applications use this project.

Tools->Runtime Object View now supports FreeRTOS. See SimpleLink Academy's 
FreeRTOS lab for more details.
